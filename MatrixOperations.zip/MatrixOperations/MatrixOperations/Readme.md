#Matrix operations
This package is to perform simple matrix operations with custom error messages and show examples of packages which do operations on matrices like correlation nad visualize them.
